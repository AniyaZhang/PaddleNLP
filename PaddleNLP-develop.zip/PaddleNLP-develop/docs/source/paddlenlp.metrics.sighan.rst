sighan
===============================

.. automodule:: paddlenlp.metrics.sighan
   :members:
   :no-undoc-members:
   :show-inheritance:
