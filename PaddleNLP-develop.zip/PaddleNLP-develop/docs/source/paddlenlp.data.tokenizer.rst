tokenizer
===============================

.. automodule:: paddlenlp.data.tokenizer
   :members:
   :no-undoc-members:
   :show-inheritance:
   :special-members: __call__
