knowledge\_mining
===========================================

.. automodule:: paddlenlp.taskflow.knowledge_mining
   :members:
   :no-undoc-members:
   :show-inheritance:
