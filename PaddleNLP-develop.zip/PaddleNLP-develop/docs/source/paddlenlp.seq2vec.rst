paddlenlp.seq2vec
=========================

.. automodule:: paddlenlp.seq2vec
   :members:
   :no-undoc-members:
   :show-inheritance:


.. toctree::
   :maxdepth: 4

   paddlenlp.seq2vec.encoder
