decoder
============================================================

.. automodule:: paddlenlp.ops.faster_transformer.transformer.decoder
   :members:
   :no-undoc-members:
