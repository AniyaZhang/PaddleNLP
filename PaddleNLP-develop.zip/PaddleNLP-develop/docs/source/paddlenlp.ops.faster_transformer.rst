faster\_transformer
=========================================

.. automodule:: paddlenlp.ops.faster_transformer
   :members:
   :no-undoc-members:
   :show-inheritance:


.. toctree::
   :maxdepth: 4

   paddlenlp.ops.faster_transformer.transformer
