sequence
================================

.. automodule:: paddlenlp.layers.sequence
   :members:
   :no-undoc-members:
   :show-inheritance:
