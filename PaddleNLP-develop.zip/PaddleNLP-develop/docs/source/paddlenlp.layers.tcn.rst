tcn
===========================

.. automodule:: paddlenlp.layers.tcn
   :members:
   :no-undoc-members:
