transformer
=================================

.. automodule:: paddlenlp.ops.transformer
   :members:
   :no-undoc-members:
   :show-inheritance:


.. toctree::
   :maxdepth: 4

   paddlenlp.ops.transformer.decoding
   paddlenlp.ops.transformer.faster_transformer
