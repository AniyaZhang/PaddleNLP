adamw
====================================

.. automodule:: paddlenlp.ops.optimizer.adamw
   :members:
   :no-undoc-members:
   :show-inheritance:
