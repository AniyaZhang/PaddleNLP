encoder
================================

.. automodule:: paddlenlp.seq2vec.encoder
   :members:
   :no-undoc-members:
   :show-inheritance:
