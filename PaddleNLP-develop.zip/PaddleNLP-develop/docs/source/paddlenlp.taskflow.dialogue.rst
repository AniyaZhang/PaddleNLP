dialogue
==================================

.. automodule:: paddlenlp.taskflow.dialogue
   :members:
   :no-undoc-members:
   :show-inheritance:
