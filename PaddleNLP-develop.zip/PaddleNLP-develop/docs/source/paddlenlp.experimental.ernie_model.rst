ernie\_model
==========================================

.. automodule:: paddlenlp.experimental.ernie_model
   :members:
   :no-undoc-members:
