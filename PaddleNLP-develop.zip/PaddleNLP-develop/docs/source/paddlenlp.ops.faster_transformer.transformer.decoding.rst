decoding
=============================================================

.. automodule:: paddlenlp.ops.faster_transformer.transformer.decoding
   :members:
   :no-undoc-members:
