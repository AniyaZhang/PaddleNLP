faster\_transformer
====================================================

.. automodule:: paddlenlp.ops.transformer.faster_transformer
   :members:
   :no-undoc-members:
   :show-inheritance:
