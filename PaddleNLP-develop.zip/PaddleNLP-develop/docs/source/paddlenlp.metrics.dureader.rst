dureader
=================================

.. automodule:: paddlenlp.metrics.dureader
   :members:
   :no-undoc-members:
   :show-inheritance:
