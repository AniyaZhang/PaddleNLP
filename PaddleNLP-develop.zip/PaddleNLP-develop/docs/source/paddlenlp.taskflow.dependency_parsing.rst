dependency\_parsing
=============================================

.. automodule:: paddlenlp.taskflow.dependency_parsing
   :members:
   :no-undoc-members:
   :show-inheritance:
