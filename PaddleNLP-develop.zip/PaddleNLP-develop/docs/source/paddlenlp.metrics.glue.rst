glue
=============================

.. automodule:: paddlenlp.metrics.glue
   :members:
   :no-undoc-members:
   :show-inheritance:
