data\_collator
====================================

.. automodule:: paddlenlp.data.data_collator
   :members:
   :no-undoc-members:
   :show-inheritance:
