information\_extraction
=================================================

.. automodule:: paddlenlp.taskflow.information_extraction
   :members:
   :no-undoc-members:
   :show-inheritance:
