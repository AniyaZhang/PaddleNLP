encoder
============================================================

.. automodule:: paddlenlp.ops.faster_transformer.transformer.encoder
   :members:
   :no-undoc-members:
   :show-inheritance:
