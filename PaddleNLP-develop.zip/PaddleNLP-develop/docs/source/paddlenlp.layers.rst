paddlenlp.layers
========================

.. automodule:: paddlenlp.layers
   :members:
   :no-undoc-members:
   :show-inheritance:


.. toctree::
   :maxdepth: 4

   paddlenlp.layers.crf
   paddlenlp.layers.sequence
   paddlenlp.layers.tcn
