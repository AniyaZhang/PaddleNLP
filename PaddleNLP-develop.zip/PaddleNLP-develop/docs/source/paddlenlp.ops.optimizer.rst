optimizer
===============================

.. automodule:: paddlenlp.ops.optimizer
   :members:
   :no-undoc-members:
   :show-inheritance:


.. toctree::
   :maxdepth: 4

   paddlenlp.ops.optimizer.adamwdl
   paddlenlp.ops.optimizer.ema
