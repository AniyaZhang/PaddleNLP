topo
===========================================

.. automodule:: paddlenlp.ops.distributed.utils.topo
   :members:
   :no-undoc-members:
