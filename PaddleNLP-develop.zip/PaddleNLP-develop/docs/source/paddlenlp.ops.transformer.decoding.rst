decoding
=========================================

.. automodule:: paddlenlp.ops.transformer.decoding
   :members:
   :no-undoc-members:
