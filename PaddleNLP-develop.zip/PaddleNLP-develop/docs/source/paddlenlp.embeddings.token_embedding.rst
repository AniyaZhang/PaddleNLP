token\_embedding
============================================

.. automodule:: paddlenlp.embeddings.token_embedding
   :members:
   :no-undoc-members:
   :show-inheritance:
