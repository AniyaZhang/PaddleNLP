crf
===========================

.. automodule:: paddlenlp.layers.crf
   :members:
   :no-undoc-members:
