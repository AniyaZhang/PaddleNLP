paddlenlp.ops
=====================

.. automodule:: paddlenlp.ops
   :members:
   :no-undoc-members:
   :show-inheritance:


.. toctree::
   :maxdepth: 4

   paddlenlp.ops.distributed
   paddlenlp.ops.faster_transformer
   paddlenlp.ops.optimizer


.. toctree::
   :maxdepth: 4

   paddlenlp.ops.einsum
   paddlenlp.ops.ext_utils
