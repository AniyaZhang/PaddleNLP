paddlenlp.datasets
==========================

.. automodule:: paddlenlp.datasets
   :members:
   :no-undoc-members:

.. toctree::
   :maxdepth: 4

   paddlenlp.datasets.dataset

