transformer
=====================================================

.. automodule:: paddlenlp.ops.faster_transformer.transformer
   :members:
   :no-undoc-members:
   :show-inheritance:


.. toctree::
   :maxdepth: 4

   paddlenlp.ops.faster_transformer.transformer.decoder
   paddlenlp.ops.faster_transformer.transformer.decoding
   paddlenlp.ops.faster_transformer.transformer.encoder
   paddlenlp.ops.faster_transformer.transformer.faster_transformer
