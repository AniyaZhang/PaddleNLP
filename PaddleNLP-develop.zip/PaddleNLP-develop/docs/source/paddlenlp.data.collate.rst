collate
=============================

.. automodule:: paddlenlp.data.collate
   :members:
   :no-undoc-members:
   :show-inheritance:
   :special-members: __call__
