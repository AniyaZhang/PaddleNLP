bleu
=============================

.. automodule:: paddlenlp.metrics.bleu
   :members:
   :no-undoc-members:
   :show-inheritance:
