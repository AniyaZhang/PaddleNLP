squad
==============================

.. automodule:: paddlenlp.metrics.squad
   :members:
   :no-undoc-members:
   :show-inheritance:
