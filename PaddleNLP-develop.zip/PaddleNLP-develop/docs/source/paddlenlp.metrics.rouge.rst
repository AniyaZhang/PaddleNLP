rouge
==============================

.. automodule:: paddlenlp.metrics.rouge
   :members:
   :no-undoc-members:
   :show-inheritance:
