distinct
=================================

.. automodule:: paddlenlp.metrics.distinct
   :members:
   :no-undoc-members:
   :show-inheritance:
