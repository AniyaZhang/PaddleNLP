perplexity
===================================

.. automodule:: paddlenlp.metrics.perplexity
   :members:
   :no-undoc-members:
   :show-inheritance:
