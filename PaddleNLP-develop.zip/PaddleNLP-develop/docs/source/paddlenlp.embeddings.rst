paddlenlp.embeddings
============================

.. automodule:: paddlenlp.embeddings
   :members:
   :no-undoc-members:
   :show-inheritance:


.. toctree::
   :maxdepth: 4

   paddlenlp.embeddings.constant
   paddlenlp.embeddings.token_embedding
