python feature_extract.py \
        --model_dir=./output \
        --corpus_file "data/corpus.csv" 