# 端到端问答

关于智能问答场景应用案例请查阅飞桨新产品RocketQA[https://github.com/PaddlePaddle/RocketQA](https://github.com/PaddlePaddle/RocketQA).
